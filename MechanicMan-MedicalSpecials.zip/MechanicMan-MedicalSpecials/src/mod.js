"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Mod {
    postDBLoad(container) {
        // get database from server
        const databaseServer = container.resolve("DatabaseServer");
        const tables = databaseServer.getTables();
        // Special Slots ID
        const pockets = tables.templates.items["627a4e6b255f7527fb05a0f6"];
        // Pushing the Grizzly into slot compatability
        pockets._props.Slots[0]._props.filters[0].Filter.push("590c657e86f77412b013051d");
        pockets._props.Slots[1]._props.filters[0].Filter.push("590c657e86f77412b013051d");
        pockets._props.Slots[2]._props.filters[0].Filter.push("590c657e86f77412b013051d");
        // Pushing the Surv12 into slot compatability
        pockets._props.Slots[0]._props.filters[0].Filter.push("5d02797c86f774203f38e30a");
        pockets._props.Slots[1]._props.filters[0].Filter.push("5d02797c86f774203f38e30a");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5d02797c86f774203f38e30a");
        // Pushing the CMS into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5d02778e86f774203e7dedbe");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5d02778e86f774203e7dedbe");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5d02778e86f774203e7dedbe");
        // Pushing the Calok-B into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5e8488fa988a8701445df1e4");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5e8488fa988a8701445df1e4");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5e8488fa988a8701445df1e4");
        // Pushing the Salewa into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("544fb45d4bdc2dee738b4568");
        pockets._props.Slots[2]._props.filters[0].Filter.push("544fb45d4bdc2dee738b4568");
        pockets._props.Slots[0]._props.filters[0].Filter.push("544fb45d4bdc2dee738b4568");
        // Pushing the Esmarch into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5e831507ea0a7c419c2f9bd9");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5e831507ea0a7c419c2f9bd9");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5e831507ea0a7c419c2f9bd9");
        // Pushing the Zagustin into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5c0e533786f7747fa23f4d47");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5c0e533786f7747fa23f4d47");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5c0e533786f7747fa23f4d47");
        // Pushing the injector case into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("619cbf7d23893217ec30b689");
        pockets._props.Slots[2]._props.filters[0].Filter.push("619cbf7d23893217ec30b689");
        pockets._props.Slots[0]._props.filters[0].Filter.push("619cbf7d23893217ec30b689");
        // Pushing the AFAK into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("60098ad7c2240c0fe85c570a");
        pockets._props.Slots[2]._props.filters[0].Filter.push("60098ad7c2240c0fe85c570a");
        pockets._props.Slots[0]._props.filters[0].Filter.push("60098ad7c2240c0fe85c570a");
        // Pushing the IFAK into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("590c678286f77426c9660122");
        pockets._props.Slots[2]._props.filters[0].Filter.push("590c678286f77426c9660122");
        pockets._props.Slots[0]._props.filters[0].Filter.push("590c678286f77426c9660122");
        // Pushing the OBD 2 into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("637b60c3b7afa97bfc3d7001");
        pockets._props.Slots[2]._props.filters[0].Filter.push("637b60c3b7afa97bfc3d7001");
        pockets._props.Slots[0]._props.filters[0].Filter.push("637b60c3b7afa97bfc3d7001");
        // Pushing the Vaseline into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5755383e24597772cb798966");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5755383e24597772cb798966");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5755383e24597772cb798966");
        // Pushing the IBU into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5af0548586f7743a532b7e99");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5af0548586f7743a532b7e99");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5af0548586f7743a532b7e99");
        // Pushing the Golden Balm into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5751a89d24597722aa0e8db0");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5751a89d24597722aa0e8db0");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5751a89d24597722aa0e8db0");
        // Pushing the Augmentin into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("590c695186f7741e566b64a2");
        pockets._props.Slots[2]._props.filters[0].Filter.push("590c695186f7741e566b64a2");
        pockets._props.Slots[0]._props.filters[0].Filter.push("590c695186f7741e566b64a2");
        // Pushing the Analgin into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("544fb37f4bdc2dee738b4567");
        pockets._props.Slots[2]._props.filters[0].Filter.push("544fb37f4bdc2dee738b4567");
        pockets._props.Slots[0]._props.filters[0].Filter.push("544fb37f4bdc2dee738b4567");
        // Pushing the Aluminum Splint into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5af0454c86f7746bf20992e8");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5af0454c86f7746bf20992e8");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5af0454c86f7746bf20992e8");
        // Pushing the Propital into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5c0e530286f7747fa1419862");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5c0e530286f7747fa1419862");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5c0e530286f7747fa1419862");
    }
}
module.exports = { mod: new Mod() };

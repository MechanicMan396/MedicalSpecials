import { DependencyContainer } from "tsyringe";

import { IPostDBLoadMod } from "@spt-aki/models/external/IPostDBLoadMod";
import { DatabaseServer } from "@spt-aki/servers/DatabaseServer";

class Mod implements IPostDBLoadMod
{
    public postDBLoad(container: DependencyContainer): void 
    {
        // get database from server
        const databaseServer = container.resolve<DatabaseServer>("DatabaseServer");
        const tables = databaseServer.getTables();

        // Special Slots ID
        const pockets = tables.templates.items["627a4e6b255f7527fb05a0f6"];

        //Meds

        // Pushing the Analgin Painkillers into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("544fb37f4bdc2dee738b4567");
        pockets._props.Slots[2]._props.filters[0].Filter.push("544fb37f4bdc2dee738b4567");
        pockets._props.Slots[0]._props.filters[0].Filter.push("544fb37f4bdc2dee738b4567");
        
        // Pushing the Augmentin Antibiotic Pills into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("590c695186f7741e566b64a2");
        pockets._props.Slots[2]._props.filters[0].Filter.push("590c695186f7741e566b64a2");
        pockets._props.Slots[0]._props.filters[0].Filter.push("590c695186f7741e566b64a2");

        // Pushing the Ibuprofen Painkillers into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5af0548586f7743a532b7e99");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5af0548586f7743a532b7e99");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5af0548586f7743a532b7e99");

        // Pushing the Vaseline Balm into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5755383e24597772cb798966");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5755383e24597772cb798966");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5755383e24597772cb798966"); 
        
        // Pushing the Golden Star Balm into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5751a89d24597722aa0e8db0");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5751a89d24597722aa0e8db0");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5751a89d24597722aa0e8db0"); 
        
        // Pushing the Aluminum Splint into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5af0454c86f7746bf20992e8");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5af0454c86f7746bf20992e8");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5af0454c86f7746bf20992e8");

        // Pushing the Immobolizing Splint into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("544fb3364bdc2d34748b456a");
        pockets._props.Slots[2]._props.filters[0].Filter.push("544fb3364bdc2d34748b456a");
        pockets._props.Slots[0]._props.filters[0].Filter.push("544fb3364bdc2d34748b456a"); 
        
        // Pushing the CMS Surgical Kit into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5d02778e86f774203e7dedbe");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5d02778e86f774203e7dedbe");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5d02778e86f774203e7dedbe");        

        // Pushing the Surv12 Field Surgical Kit into slot compatability
        pockets._props.Slots[0]._props.filters[0].Filter.push("5d02797c86f774203f38e30a");
        pockets._props.Slots[1]._props.filters[0].Filter.push("5d02797c86f774203f38e30a");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5d02797c86f774203f38e30a");

        // Pushing the Aseptic Bandage into slot compatability
        pockets._props.Slots[0]._props.filters[0].Filter.push("544fb25a4bdc2dfb738b4567");
        pockets._props.Slots[1]._props.filters[0].Filter.push("544fb25a4bdc2dfb738b4567");
        pockets._props.Slots[2]._props.filters[0].Filter.push("544fb25a4bdc2dfb738b4567");

        // Pushing the Army Bandage into slot compatability
        pockets._props.Slots[0]._props.filters[0].Filter.push("5751a25924597722c463c472");
        pockets._props.Slots[1]._props.filters[0].Filter.push("5751a25924597722c463c472");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5751a25924597722c463c472");

        // Pushing the CAT Hemostatic Tourniquet into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("60098af40accd37ef2175f27");
        pockets._props.Slots[2]._props.filters[0].Filter.push("60098af40accd37ef2175f27");
        pockets._props.Slots[0]._props.filters[0].Filter.push("60098af40accd37ef2175f27");        

        // Pushing the Calok-B into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5e8488fa988a8701445df1e4");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5e8488fa988a8701445df1e4");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5e8488fa988a8701445df1e4");

        // Pushing the Esmarch into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5e831507ea0a7c419c2f9bd9");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5e831507ea0a7c419c2f9bd9");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5e831507ea0a7c419c2f9bd9");

        // Pushing the AI-2 Medkit into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5755356824597772cb798962");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5755356824597772cb798962");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5755356824597772cb798962");        
        
        // Pushing the Car First Aid Kit into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("590c661e86f7741e566b646a");
        pockets._props.Slots[2]._props.filters[0].Filter.push("590c661e86f7741e566b646a");
        pockets._props.Slots[0]._props.filters[0].Filter.push("590c661e86f7741e566b646a");        

        // Pushing the Salewa First Aid Kit into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("544fb45d4bdc2dee738b4568");
        pockets._props.Slots[2]._props.filters[0].Filter.push("544fb45d4bdc2dee738b4568");
        pockets._props.Slots[0]._props.filters[0].Filter.push("544fb45d4bdc2dee738b4568");
        
        // Pushing the IFAK into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("590c678286f77426c9660122");
        pockets._props.Slots[2]._props.filters[0].Filter.push("590c678286f77426c9660122");
        pockets._props.Slots[0]._props.filters[0].Filter.push("590c678286f77426c9660122");
        
        // Pushing the AFAK into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("60098ad7c2240c0fe85c570a");
        pockets._props.Slots[2]._props.filters[0].Filter.push("60098ad7c2240c0fe85c570a");
        pockets._props.Slots[0]._props.filters[0].Filter.push("60098ad7c2240c0fe85c570a");

        // Pushing the Grizzly into slot compatability
        pockets._props.Slots[0]._props.filters[0].Filter.push("590c657e86f77412b013051d");
        pockets._props.Slots[1]._props.filters[0].Filter.push("590c657e86f77412b013051d");
        pockets._props.Slots[2]._props.filters[0].Filter.push("590c657e86f77412b013051d");

        //Injectors
        
        // Pushing the Morphine Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("544fb3f34bdc2d03748b456a");
        pockets._props.Slots[2]._props.filters[0].Filter.push("544fb3f34bdc2d03748b456a");
        pockets._props.Slots[0]._props.filters[0].Filter.push("544fb3f34bdc2d03748b456a");

        // Pushing the L1 (Norepinephrine) Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5ed515e03a40a50460332579");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5ed515e03a40a50460332579");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5ed515e03a40a50460332579");

        // Pushing the Trimadol Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("637b620db7afa97bfc3d7009");
        pockets._props.Slots[2]._props.filters[0].Filter.push("637b620db7afa97bfc3d7009");
        pockets._props.Slots[0]._props.filters[0].Filter.push("637b620db7afa97bfc3d7009");

        // Pushing the Adrenaline Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5c10c8fd86f7743d7d706df3");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5c10c8fd86f7743d7d706df3");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5c10c8fd86f7743d7d706df3");

        // Pushing the Propital Regenerative Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5c0e530286f7747fa1419862");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5c0e530286f7747fa1419862");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5c0e530286f7747fa1419862");

        // Pushing the eTG-Change Regenerative Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5c0e534186f7747fa1419867");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5c0e534186f7747fa1419867");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5c0e534186f7747fa1419867");

        // Pushing the xTG-12 Antidote Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5fca138c2a7b221b2852a5c6");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5fca138c2a7b221b2852a5c6");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5fca138c2a7b221b2852a5c6"); 
        
        // Pushing the Perfotoran (Blue Blood) Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("637b6251104668754b72f8f9");
        pockets._props.Slots[2]._props.filters[0].Filter.push("637b6251104668754b72f8f9");
        pockets._props.Slots[0]._props.filters[0].Filter.push("637b6251104668754b72f8f9");

        // Pushing the AHF1-M Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5ed515f6915ec335206e4152");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5ed515f6915ec335206e4152");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5ed515f6915ec335206e4152");

        // Pushing the Zagustin Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5c0e533786f7747fa23f4d47");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5c0e533786f7747fa23f4d47");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5c0e533786f7747fa23f4d47");

        // Pushing the PNB (Product 16) Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("637b6179104668754b72f8f5");
        pockets._props.Slots[2]._props.filters[0].Filter.push("637b6179104668754b72f8f5");
        pockets._props.Slots[0]._props.filters[0].Filter.push("637b6179104668754b72f8f5");

        // Pushing the P22 (Product 22) Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5ed515ece452db0eb56fc028");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5ed515ece452db0eb56fc028");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5ed515ece452db0eb56fc028");

        // Pushing the Meldonin Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5ed5160a87bb8443d10680b5");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5ed5160a87bb8443d10680b5");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5ed5160a87bb8443d10680b5");

        // Pushing the SJ1 TGLabs Combat Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5c0e531286f7747fa54205c2");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5c0e531286f7747fa54205c2");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5c0e531286f7747fa54205c2");

        // Pushing the SJ6 TGLabs Combat Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5c0e531d86f7747fa23f4d42");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5c0e531d86f7747fa23f4d42");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5c0e531d86f7747fa23f4d42");

        // Pushing the 3-(b-TG) Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5ed515c8d380ab312177c0fa");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5ed515c8d380ab312177c0fa");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5ed515c8d380ab312177c0fa");

        // Pushing the "Obdolbos" Cocktail Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5ed5166ad380ab312177c100");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5ed5166ad380ab312177c100");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5ed5166ad380ab312177c100");

        // Pushing the "Obdolbos 2" Cocktail Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("637b60c3b7afa97bfc3d7001");
        pockets._props.Slots[2]._props.filters[0].Filter.push("637b60c3b7afa97bfc3d7001");
        pockets._props.Slots[0]._props.filters[0].Filter.push("637b60c3b7afa97bfc3d7001");

        // Pushing the M.U.L.E. Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5ed51652f6c34d2cc26336a1");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5ed51652f6c34d2cc26336a1");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5ed51652f6c34d2cc26336a1");

        // Pushing the SJ9 TGLabs Combat Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5fca13ca637ee0341a484f46");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5fca13ca637ee0341a484f46");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5fca13ca637ee0341a484f46");

        // Pushing the SJ12 TGLabs Combat Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("637b612fb7afa97bfc3d7005");
        pockets._props.Slots[2]._props.filters[0].Filter.push("637b612fb7afa97bfc3d7005");
        pockets._props.Slots[0]._props.filters[0].Filter.push("637b612fb7afa97bfc3d7005");

        //Cases

        // Pushing the Injector Case into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("619cbf7d23893217ec30b689");
        pockets._props.Slots[2]._props.filters[0].Filter.push("619cbf7d23893217ec30b689");
        pockets._props.Slots[0]._props.filters[0].Filter.push("619cbf7d23893217ec30b689");

        //GoblinKing Meds

        // Pushing the Goblin's IFAK into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5448f39d4bdc2d0a728b4568");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5448f39d4bdc2d0a728b4568");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5448f39d4bdc2d0a728b4568");

        // Pushing the ElDiablosBlood Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5448f3a64bdc2d60728b456a");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5448f3a64bdc2d60728b456a");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5448f3a64bdc2d60728b456a");

        // Pushing the Lightning Stimulant Injector into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5448f3a64bdc2d60728b456a");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5448f3a64bdc2d60728b456a");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5448f3a64bdc2d60728b456a");        
    }
}

module.exports = { mod: new Mod() }
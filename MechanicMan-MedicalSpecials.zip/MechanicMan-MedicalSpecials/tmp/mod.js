"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Mod {
    postDBLoad(container) {
        // get database from server
        const databaseServer = container.resolve("DatabaseServer");
        const tables = databaseServer.getTables();
        // Special Slots ID
        const pockets = tables.templates.items["627a4e6b255f7527fb05a0f6"];
        // Pushing the Grizzly into slot compatability
        pockets._props.Slots[0]._props.filters[0].Filter.push("590c657e86f77412b013051d");
        pockets._props.Slots[1]._props.filters[0].Filter.push("590c657e86f77412b013051d");
        pockets._props.Slots[2]._props.filters[0].Filter.push("590c657e86f77412b013051d");
        // Pushing the Surv12 into slot compatability
        pockets._props.Slots[0]._props.filters[0].Filter.push("5d02797c86f774203f38e30a");
        pockets._props.Slots[1]._props.filters[0].Filter.push("5d02797c86f774203f38e30a");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5d02797c86f774203f38e30a");
        // Pushing the CMS into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5d02778e86f774203e7dedbe");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5d02778e86f774203e7dedbe");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5d02778e86f774203e7dedbe");
        // Pushing the Calok-B into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("5e8488fa988a8701445df1e4");
        pockets._props.Slots[2]._props.filters[0].Filter.push("5e8488fa988a8701445df1e4");
        pockets._props.Slots[0]._props.filters[0].Filter.push("5e8488fa988a8701445df1e4");
        // Pushing the Salewa into slot compatability
        pockets._props.Slots[1]._props.filters[0].Filter.push("544fb45d4bdc2dee738b4568");
        pockets._props.Slots[2]._props.filters[0].Filter.push("544fb45d4bdc2dee738b4568");
        pockets._props.Slots[0]._props.filters[0].Filter.push("544fb45d4bdc2dee738b4568");
    }
}
module.exports = { mod: new Mod() };

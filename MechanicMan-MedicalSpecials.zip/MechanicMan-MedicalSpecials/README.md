I created this as an attempt to make a less "cheater feel" specials mods alternative to JBS4BMX version "Special Slots" 

I loved his mod but felt to cheat like being able to carry 4 backpacks full of shit. 

As an alternative this mod only allows you to store medical items in special slots. 

I think this mod goes well with Realism. 